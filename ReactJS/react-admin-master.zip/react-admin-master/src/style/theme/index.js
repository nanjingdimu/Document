/**
 * Created by hao.cheng on 2017/5/6.
 */
import themeinfo from './theme-info.json';
import themegrey from './theme-grey.json';
import themedanger from './theme-danger.json';
import themewarn from './theme-warn.json';

export default { themeinfo, themegrey, themedanger, themewarn};